# 📊 SISTEMA DE LOGS - BARBERSHOP PRO

## 🗂️ Estrutura de Logs

### **Frontend Logs (por Tela/Componente):**
```
logs/frontend/
├── dashboard/          # Dashboard principal
├── appointments/       # Tela de agendamentos
├── clients/           # Gestão de clientes
├── barbers/           # Gestão de barbeiros
├── services/          # Serviços da barbearia
├── products/          # Produtos e estoque
├── sales/             # Vendas e relatórios
├── pdv/              # Point of Sale
├── auth/             # Autenticação e login
└── components/       # Componentes reutilizáveis
```

### **Backend Logs (por Módulo):**
```
logs/backend/
├── api/              # Endpoints da API
├── database/         # Queries e conexões DB
├── auth/             # Autenticação JWT
├── middleware/       # Middlewares Express
├── routes/           # Roteamento
└── utils/            # Utilitários
```

### **System Logs:**
```
logs/system/          # Logs do sistema Docker/Nginx
logs/errors/          # Erros críticos centralizados
logs/performance/     # Métricas de performance
logs/audit/           # Auditoria de ações
```

## 📝 Padrão de Nomenclatura

### **Arquivos de Log:**
- `YYYY-MM-DD-{component}.log` - Log do dia atual
- `YYYY-MM-DD-{component}-error.log` - Erros específicos
- `YYYY-MM-DD-{component}-debug.log` - Debug detalhado

### **Exemplo:**
```
2025-09-23-dashboard.log
2025-09-23-appointments-error.log
2025-09-23-api-debug.log
```

## 🏷️ Níveis de Log

1. **ERROR** - Erros críticos que impedem funcionamento
2. **WARN** - Avisos importantes que requerem atenção
3. **INFO** - Informações gerais do fluxo
4. **DEBUG** - Informações detalhadas para debug
5. **TRACE** - Rastreamento completo de execução

## 📊 Formato de Log

### **Estrutura JSON:**
```json
{
  "timestamp": "2025-09-23T19:30:00.000Z",
  "level": "INFO",
  "component": "dashboard",
  "action": "load_data",
  "user_id": "user-123",
  "barbershop_id": "bb-001",
  "message": "Dashboard carregado com sucesso",
  "data": {
    "metrics_loaded": true,
    "load_time": 1200
  },
  "request_id": "req-456",
  "session_id": "sess-789"
}
```

## 🔍 Casos de Uso

### **Mapeamento de Erros por Tela:**
- Identificar quais telas têm mais problemas
- Correlacionar erros com ações específicas
- Rastrear jornada do usuário até o erro

### **Performance Monitoring:**
- Tempo de carregamento por tela
- Queries mais lentas
- Gargalos de API

### **Auditoria:**
- Ações críticas (CRUD)
- Login/logout
- Mudanças de configuração

## 🛠️ Ferramentas

- **Frontend:** Custom Logger + LocalStorage backup
- **Backend:** Winston.js + File rotation
- **Centralized:** ELK Stack ready
- **Alerts:** Email/Slack integration ready